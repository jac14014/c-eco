export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const { stage, stageName, input, history = [] } = req.body || {};
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: 'Missing OPENAI_API_KEY in Vercel environment variables.' });
  if (typeof input !== 'string' || !input.trim()) return res.status(400).json({ error: 'Missing analysis input.' });
  const system = `You are the c-ECO Structural Review Engine. Inspect structural sufficiency only. Return only JSON with keys status and content. status must be sufficient, insufficient, or invalid. Be strict. Do not comfort, praise, or tutor. No skips. Stages: 0 Case Anchor: asset, instrument, location/bioregion. 1 System: biophysical system, degrading variable, boundary. 2 TFP Variables: P, ΔV, σ, Lr. 3 Trajectory: sustained direction, stability questioned. 4 Recognition-Action Gap: recognized risk linked to operational/legal action failure. 5 Decision Pressure: consequence, reversibility, contradiction pressure.`;
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-5.5',
        input: [ { role: 'system', content: system }, { role: 'user', content: JSON.stringify({ stage, stageName, input, priorHistory: history }) } ],
        text: { format: { type: 'json_schema', name: 'structural_review', schema: { type: 'object', additionalProperties: false, properties: { status: { type: 'string', enum: ['sufficient','insufficient','invalid'] }, content: { type: 'string' } }, required: ['status','content'] } } }
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || 'OpenAI API error' });
    return res.status(200).json(JSON.parse(data.output_text));
  } catch (error) { return res.status(500).json({ error: error.message || 'Server error' }); }
}
